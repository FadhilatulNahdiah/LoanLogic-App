package com.example.LoanLogic

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.LoanLogic.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {
            startActivity(Intent(this, DataDiri::class.java))
        }

        binding.button2.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        binding.button3.setOnClickListener {
            startActivity(Intent(this, Predict::class.java))
        }

        binding.button4.setOnClickListener {
            startActivity(Intent(this, DataDiri::class.java))
        }

        binding.button5.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}