package com.example.LoanLogic

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.LoanLogic.databinding.ActivityDataDiriBinding

class DataDiri : AppCompatActivity() {
    private lateinit var binding: ActivityDataDiriBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDataDiriBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSimpandatadiri.setOnClickListener{
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }


}