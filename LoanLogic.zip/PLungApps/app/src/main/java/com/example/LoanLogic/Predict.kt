package com.example.LoanLogic

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.LoanLogic.databinding.ActivityPredictBinding

class Predict : AppCompatActivity() {
    private lateinit var binding: ActivityPredictBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPredictBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button2.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        binding.button3.setOnClickListener {
            startActivity(Intent(this, Predict::class.java))
        }

        binding.button4.setOnClickListener {
            startActivity(Intent(this, DataDiri::class.java))
        }

        binding.button5.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}